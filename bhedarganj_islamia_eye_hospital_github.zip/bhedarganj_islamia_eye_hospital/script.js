const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'মেনু বন্ধ করুন' : 'মেনু খুলুন');
  menuToggle.textContent = open ? '×' : '☰';
});
mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'মেনু খুলুন');
  menuToggle.textContent = '☰';
}));
document.getElementById('year').textContent = new Date().getFullYear();

const bookingForm = document.getElementById('bookingForm');
if (bookingForm) {
  bookingForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!bookingForm.reportValidity()) return;
    const data = new FormData(bookingForm);
    const message = [
      'ভেদরগঞ্জ ইসলামিয়া চক্ষু হাসপাতাল — অনলাইন সিরিয়ালের অনুরোধ',
      'রোগীর নাম: ' + (data.get('patientName') || ''),
      'মোবাইল: ' + (data.get('patientPhone') || ''),
      'চিকিৎসক: ' + (data.get('doctorChoice') || ''),
      'পছন্দের তারিখ: ' + (data.get('visitDate') || 'উল্লেখ করা হয়নি'),
      'সমস্যার ধরন: ' + (data.get('patientReason') || ''),
      'অতিরিক্ত তথ্য: ' + (data.get('patientMessage') || 'নেই'),
      '',
      'অনুগ্রহ করে সিরিয়াল ও সময় নিশ্চিত করুন।'
    ].join('\\n');
    document.getElementById('bookingStatus').textContent = 'WhatsApp খুলছে। সেখানে বার্তাটি দেখে Send চাপুন।';
    window.open('https://wa.me/8801348980793?text=' + encodeURIComponent(message), '_blank', 'noopener');
  });
}
